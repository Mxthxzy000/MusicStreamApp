import { Play } from "lucide-react"
import { FavoriteButton } from "./FavoriteButton"
import React, { useRef, useState, useEffect } from "react";

export default function ContentCard({ content }) {
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
        audioRef.current = null;
      }
    };
  }, []);

  const handlePlayPause = async () => {
    if (!content?.audio_url) {
      console.warn("Conteúdo não tem audio_url");
      return;
    }

    // pause any other playing audio
    if (window.__currentAudio && window.__currentAudio !== audioRef.current) {
      try { window.__currentAudio.pause(); } catch (e) {}
    }

    if (!audioRef.current) {
      audioRef.current = new Audio(content.audio_url);
      audioRef.current.preload = "auto";
      audioRef.current.addEventListener("ended", () => setIsPlaying(false));
      audioRef.current.addEventListener("pause", () => setIsPlaying(false));
      audioRef.current.addEventListener("play", () => setIsPlaying(true));
    } else if (audioRef.current.src !== content.audio_url) {
      audioRef.current.src = content.audio_url;
    }

    window.__currentAudio = audioRef.current;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      try {
        await audioRef.current.play();
        setIsPlaying(true);
      } catch (err) {
        console.error("Erro ao reproduzir áudio:", err);
        setIsPlaying(false);
      }
    }
  };

  return (
    <article className="group relative overflow-hidden rounded-2xl bg-card border border-border transition-all hover:border-primary/60 hover:neon-border">
      <div className="relative aspect-square overflow-hidden">
        <img
          src={content.cover_url || "/placeholder.svg"}
          alt={`Capa de ${content.title}`}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent opacity-80" />

        <div className="absolute right-3 top-3">
          <FavoriteButton contentId={content.id} size="sm" />
        </div>

        <div className="absolute bottom-3 left-3 flex h-11 w-11 items-center justify-center rounded-full bg-primary text-primary-foreground opacity-0 shadow-lg transition-all duration-300 group-hover:opacity-100">
          <Play className="h-5 w-5 fill-current" />
        </div>
      </div>

      <div className="p-4">
        {content.genre?.name && (
          <span className="text-xs font-semibold uppercase tracking-wider text-secondary">
            {content.genre.name}
          </span>
        )}
        <h3 className="mt-1 truncate font-display text-base font-semibold text-card-foreground">
          {content.title}
        </h3>
        <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
          {content.synopsis}
        </p>
      </div>

      <button aria-label={isPlaying ? "Pause" : "Play"} onClick={handlePlayPause} className="play-button">
        {isPlaying ? "Pause" : "Play"}
      </button>
    </article>
  )
}
